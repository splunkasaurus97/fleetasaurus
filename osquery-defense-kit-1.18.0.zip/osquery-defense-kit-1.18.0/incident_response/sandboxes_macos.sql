-- Lists the application bundle that owns a sandbox label.
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  sandboxes;
