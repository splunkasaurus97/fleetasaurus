-- Return the list of interface addresses (IPv6)
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  interface_ipv6;
