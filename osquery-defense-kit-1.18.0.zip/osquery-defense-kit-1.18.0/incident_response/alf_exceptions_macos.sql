-- Retrieves the exceptions for the Application Layer Firewall in OSX.
--
-- tags: postmortem
SELECT
  *
FROM
  alf_exceptions;
