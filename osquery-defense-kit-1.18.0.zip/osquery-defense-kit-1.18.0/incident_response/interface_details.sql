-- Return stats on network interfaces
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  interface_details
