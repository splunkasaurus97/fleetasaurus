-- Retrieves all the currently installed certificates on a system
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  certificates;
