-- Retrieves System Integrity Protection Settings data
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  sip_config;
