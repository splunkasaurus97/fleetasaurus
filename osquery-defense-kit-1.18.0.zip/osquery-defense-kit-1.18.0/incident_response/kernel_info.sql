-- Return basic kernel information
-- tags: postmortem
SELECT
  *
FROM
  kernel_info;
