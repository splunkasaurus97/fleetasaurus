-- Return macOS package install history
--
-- tags: postmortem
SELECT
  *
FROM
  package_install_history;
