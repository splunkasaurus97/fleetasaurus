-- Return the list of Docker images
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  docker_images;
