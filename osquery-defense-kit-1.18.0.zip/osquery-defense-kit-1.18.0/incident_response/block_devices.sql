-- Retrieves all block devices known to the system
-- platform: posix
-- tags: postmortem seldom
SELECT
  *
FROM
  block_devices
