-- Retrieves a list of debian packages
-- tags: postmortem
-- platform: Linux
SELECT
  *
FROM
  deb_packages;
