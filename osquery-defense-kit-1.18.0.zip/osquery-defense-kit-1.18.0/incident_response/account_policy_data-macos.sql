-- Retrieves account policy data, such as creation time
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  account_policy_data;
