-- Return the OS version including patch level
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  os_version;
