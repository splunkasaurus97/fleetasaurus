-- Retrieves entries from the macOS authorization mechanisms db
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  authorization_mechanisms;
