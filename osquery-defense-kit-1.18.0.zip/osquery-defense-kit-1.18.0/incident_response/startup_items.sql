-- Retrieve most programs that are part of a systems startup (multi-platform)
--
-- tags: postmortem
SELECT
  *
FROM
  startup_items;
