-- Return the list of sysctl values
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  system_controls;
