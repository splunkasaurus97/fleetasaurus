-- Retrieves the current filters and chains per filter in the target system.
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  iptables;
