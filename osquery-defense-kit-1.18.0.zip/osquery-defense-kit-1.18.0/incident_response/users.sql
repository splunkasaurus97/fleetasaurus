-- Returns a list of users
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  users
