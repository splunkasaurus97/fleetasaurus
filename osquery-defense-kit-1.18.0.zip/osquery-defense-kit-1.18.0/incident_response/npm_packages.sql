-- Return the list of npm packages
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  npm_packages;
