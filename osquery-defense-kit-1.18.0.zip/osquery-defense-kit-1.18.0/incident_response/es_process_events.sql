-- Dump a list of process execution events from EndpointSecurity
--
-- platform: darwin
-- tags: events extra
SELECT
  *
FROM
  es_process_events;
