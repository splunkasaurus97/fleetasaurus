-- Retrieves the current disk encryption status for the target system.
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  disk_encryption;
