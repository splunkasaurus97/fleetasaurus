-- Retrieves entries from the macOS nvram database
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  nvram;
