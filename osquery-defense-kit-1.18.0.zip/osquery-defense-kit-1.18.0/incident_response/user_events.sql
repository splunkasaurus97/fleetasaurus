-- Return the list of audit user events
--
-- tags: postmortem events
-- platform: linux
SELECT
  *
FROM
  user_events;
