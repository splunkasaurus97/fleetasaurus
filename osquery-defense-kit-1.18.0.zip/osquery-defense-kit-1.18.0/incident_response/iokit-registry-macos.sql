-- Retrieves IOKit registry
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  iokit_registry;
