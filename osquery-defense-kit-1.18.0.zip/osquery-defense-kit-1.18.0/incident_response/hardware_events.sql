-- Return hardware events
--
-- tags: postmortem events
-- platform: posix
SELECT
  *
FROM
  hardware_events;
