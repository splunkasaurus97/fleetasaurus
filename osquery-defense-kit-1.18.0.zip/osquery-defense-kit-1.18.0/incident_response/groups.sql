-- Return the list of POSIX groups on the system
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  groups;
