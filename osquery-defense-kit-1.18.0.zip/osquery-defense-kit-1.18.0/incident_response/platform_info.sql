-- Return hardware platform info (UEFI)
--
-- tags: postmortem seldom
SELECT
  *
FROM
  platform_info
