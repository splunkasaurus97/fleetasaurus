-- Retrieves the configuration values for the Application Layer Firewall for OSX.
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  alf;
