-- Retrieves the services for the Application Layer Firewall in OSX.
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  alf_services;
