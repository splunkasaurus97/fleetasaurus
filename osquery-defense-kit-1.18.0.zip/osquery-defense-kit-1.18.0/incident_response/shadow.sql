-- Return user data from /etc/shadow
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  shadow;
