-- Return the list of USB devices
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  usb_devices;
