-- Retrieves currently running applications
--
-- tags: postmortem disabled-privacy
-- platform: darwin
SELECT
  *
FROM
  running_apps;
