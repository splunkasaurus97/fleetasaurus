-- Retrieves software packages with access to listening in on keyboard/mouse events
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  event_taps;
