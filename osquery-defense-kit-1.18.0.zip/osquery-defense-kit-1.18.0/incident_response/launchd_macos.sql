-- macOS launchd entries
--
-- platform: darwin
SELECT
  *
FROM
  launchd;
