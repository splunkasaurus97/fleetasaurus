-- Return the list of seccomp events
--
-- tags: postmortem events
-- platform: linux
SELECT
  *
FROM
  seccomp_events;
