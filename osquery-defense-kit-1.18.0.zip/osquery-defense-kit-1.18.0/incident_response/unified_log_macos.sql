-- Retrieves recent entries from the macOS unified log
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  unified_log;
