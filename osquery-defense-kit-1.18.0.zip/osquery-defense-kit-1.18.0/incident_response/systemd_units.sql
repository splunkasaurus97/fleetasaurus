-- Returns a list of systemd units
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  systemd_units;
