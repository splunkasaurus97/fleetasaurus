-- Retrieves the list of the latest logins with PID, username and timestamp.
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  last;
