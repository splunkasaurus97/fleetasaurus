-- Return the Docker image history on a machine
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  docker_image_history
