-- Retrieves the current list of mounted drives in the target system.
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  mounts;
