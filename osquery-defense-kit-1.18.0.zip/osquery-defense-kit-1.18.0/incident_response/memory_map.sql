-- Returns the OS memory region map.
--
-- tags: postmortem
-- platform: linux
SELECT
  *
FROM
  memory_map;
