-- Return the list of syslog events
--
-- tags: postmortem events
-- platform: linux
SELECT
  *
FROM
  syslog_events;
