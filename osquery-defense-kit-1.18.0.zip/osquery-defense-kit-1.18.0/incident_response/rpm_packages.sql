-- Retrieves a list of RPM packages
-- tags: postmortem
-- platform: Linux
SELECT
  *
FROM
  rpm_packages;
