-- Dump a list of homebrew packages
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  homebrew_packages;
