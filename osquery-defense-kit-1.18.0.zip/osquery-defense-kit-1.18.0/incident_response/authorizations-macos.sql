-- Retrieves entries from the macOS authorization rights db
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  authorizations;
