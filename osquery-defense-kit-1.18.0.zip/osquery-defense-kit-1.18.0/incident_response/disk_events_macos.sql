-- Retrieves disk image (DMG) events
--
-- tags: postmortem events
-- platform: darwin
SELECT
  *
FROM
  disk_events;
