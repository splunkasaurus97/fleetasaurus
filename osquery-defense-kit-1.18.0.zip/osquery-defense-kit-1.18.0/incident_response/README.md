The `incident_response` queries originate from the upstream osquery project:

<https://github.com/osquery/osquery/blob/master/packs/incident-response.conf>

Additional tables have been added and the intervals have been modified.
