-- Retrieves the list of application scheme/protocol-based IPC handlers.
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  app_schemes;
