-- Retrieves all the currently installed applications in the target OSX system.
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  apps;
