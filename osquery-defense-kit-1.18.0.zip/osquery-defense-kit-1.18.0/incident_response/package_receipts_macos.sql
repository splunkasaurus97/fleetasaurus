-- Return macOS package receipts
--
-- tags: postmortem
SELECT
  *
FROM
  package_receipts;
