-- Retrieves entries from the macOS preferences database
--
-- tags: postmortem
-- platform: darwin
SELECT
  *
FROM
  preferences;
