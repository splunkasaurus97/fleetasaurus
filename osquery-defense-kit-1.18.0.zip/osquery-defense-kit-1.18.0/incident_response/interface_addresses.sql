-- Return the list of interface addresses
--
-- tags: postmortem
-- platform: posix
SELECT
  *
FROM
  interface_addresses;
