These are reference query fragments that are meant to be shared across queries.

